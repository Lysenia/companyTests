package newcompany.newcompanytests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;



public class AppTest
{
    WebDriver driver;

   // runs before each method in class
    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        
   // sets the implicit wait and full-screen mode and  
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().window().fullscreen();

    }

    @Test
    public void getSeleniumSearch() {
    	
    	//navigate to google chrome
        driver.get("https://www.google.com");
    // locate the search filed and type "Selenium"
        WebElement searchInput = driver.findElement(By.name("q"));
        searchInput.sendKeys("Selenium");
        searchInput.submit();
    // wait until the list of results is dispalyed
        new WebDriverWait(driver, 10).until(ExpectedConditions.presenceOfElementLocated(By.id("rcnt")));
    // find and click on the result that matches link 'https://www.selenium.dev/'
        WebElement result = driver.findElement(By.xpath("//a[@href='https://www.selenium.dev/']"));
        result.click();
     // validating the header text displayed is correct
        WebElement seleniumTitle = driver.findElement(By.xpath("//div[@class='container td-overlay__inner']//div[@class='text-center']/h1"));
        String actualTitle = seleniumTitle.getText();
        String expectedTitle = "Selenium automates browsers. That's it!";
        Assert.assertEquals(actualTitle, expectedTitle);

    }
}